import React, { Component } from "react";
import MetaTags from 'react-meta-tags';
import PropTypes from "prop-types"
import {
    Col,
    Container,
    Row,
    CardTitle,
    Button,
    Table,
    Modal,
    CardBody,
    CardText,
    Card,

} from "reactstrap";
import axios from "axios";
import { Link } from "react-router-dom";
import Select from 'react-select';
import { DatePicker } from 'antd';
import moment from 'moment';
// import 'antd/dist/antd.css';
// import CardComp from './Components/CardComp'
import { Image } from 'antd';
import { ImgOverlay } from 'image-overlay-react'
import 'image-overlay-react/dist/index.css'
// import { Modal } from 'antd';
import urlSocket from './urlSocket';
import ImageUrl from "./imageUrl";
import './index.css';


const { RangePicker } = DatePicker;


class Report extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showTable2: false,
            tbIndex: 0,
            temp_index: 0,
            filter_comp_name: "",
            filter_comp_code: "",
            config_positive:"",
            config_negative:"",
            config_posble_match:"",
            positive:'',
            negative:'',
            posble_match:'',
            filter_date: "",
            comp_name: "",
            comp_code: "",
            date: "",
            okCount: "",
            notokCount: "",
            totalCount: "",
            posblMatchCount: "",
            no_objCount: "",
            incorrect_obj:'',
            dateWiseData: [],
            timeWise_filterdata: [],
            dataloaded: false,
            showModal: false,
            modal_data: {},
            timeWiseData: [

            ],

        }
    }

    componentDidMount() {
        var timeWiseData = JSON.parse(sessionStorage.getItem("timeWiseData"))
        var dateWiseData = JSON.parse(sessionStorage.getItem("dateWiseData"))
        console.log('dateWiseData', dateWiseData)
        console.log('comp_name', timeWiseData)
        let ok_Count = timeWiseData.ok
        let notok_Count = timeWiseData.notok
        let total_Count = timeWiseData.total
        let posblMatch_Count = timeWiseData.posbl_match
        let noobj_Count = timeWiseData.no_obj
        let incorrect_obj = timeWiseData.incorrect_obj
        this.setState({ timeWiseData, dateWiseData, okCount: ok_Count, notokCount: notok_Count, totalCount: total_Count, posblMatchCount: posblMatch_Count, no_objCount: noobj_Count, config_positive:timeWiseData.config_positive, config_negative:timeWiseData.config_negative, config_posble_match:timeWiseData.config_posble_match,incorrect_obj:incorrect_obj })
        this.labelData(timeWiseData)
        this.compListAPICall(timeWiseData)
    }


    compListAPICall = (timeWiseData) => {
        //filter_comp_code = this.state.filter_comp_code
        console.log('timeWiseData', timeWiseData)
        let filter_comp_name = timeWiseData.comp_name
        console.log('filter_comp_name', filter_comp_name)
        let filter_comp_code = timeWiseData.comp_code
        let filter_date = timeWiseData.date
        let station_id = timeWiseData.station_id

        try {
            urlSocket.post('/timeWise_filterData', { 'comp_name': filter_comp_name, 'comp_code': filter_comp_code, 'station_id':station_id, 'date': filter_date },
                { mode: 'no-cors' })
                .then((response) => {
                    let timeWise_filterdata = response.data
                    console.log("timeWise_filterdata95", timeWise_filterdata)
                    let comp_name = timeWise_filterdata[0].comp_name
                    let comp_code = timeWise_filterdata[0].comp_code
                    let Date = timeWise_filterdata[0].date
                    let result = timeWise_filterdata[0].result
                    let station_id = timeWise_filterdata[0].station_id
                    console.log('Result', result)
                    console.log('CompNam...', comp_name)                   
                    this.setState({ timeWise_filterdata, comp_name: comp_name, comp_code: comp_code, date: Date, result: result, station_id:station_id, dataloaded: true })
                })
                .catch((error) => {

                    console.log(error)
                })
        } catch (error) {

        }
    }
    labelData = (timeWiseData) => {
        console.log('timeWiseData113', timeWiseData)
        try {
            urlSocket.post('/comp_Data', { 'comp_name': timeWiseData.comp_name, 'comp_code': timeWiseData.comp_code },
                { mode: 'no-cors' })
                .then((response) => {
                    let timeWise_filterdata = response.data
                    console.log("Comp_data", timeWise_filterdata)
                    this.setState({ positive:response.data[0].positive, negative: response.data[0].negative, posble_match:response.data[0].posble_match, dataloaded:true })
                })
                .catch((error) => {
                    console.log(error)
                })
        } catch (error) {

        }
    }

    status_filter = (status) => {
        console.log('first131', status)
        let comp_name = this.state.comp_name
        let comp_code = this.state.comp_code
        let station_id = this.state.station_id
        let date = this.state.date
        let result = status
        try {
            urlSocket.post('/result_filterData', { 'comp_name': comp_name, 'comp_code': comp_code, 'date': date, 'result': result, 'station_id':station_id },
                { mode: 'no-cors' })
                .then((response) => {
                    let filtered_data = response.data
                    console.log("141", filtered_data)
                    // let comp_name = timeWise_filterdata[0].comp_name
                    // let comp_code = timeWise_filterdata[0].comp_code
                    // let Date = timeWise_filterdata[0].date
                    // console.log('CompNam...', comp_name)
                    this.setState({ timeWise_filterdata: filtered_data })
                })
                .catch((error) => {

                    console.log(error)
                })
        } catch (error) {

        }
    }

    backButton = () => {
        let data = {
            startDate: this.state.dateWiseData.startDate,
            endDate: this.state.dateWiseData.endDate,
            comp_name: this.state.dateWiseData.comp_name,
            comp_code: this.state.dateWiseData.comp_code
        }
        // console.log('data', data)
        sessionStorage.removeItem("dateWiseData")
        sessionStorage.setItem("dateWiseData", JSON.stringify(data))

    }


    getImage = (data1) => {
        // console.log('data1', data1)
        if (data1 !== undefined) {
            console.log('data1', data1)
            let baseurl = ImageUrl
            let replace = data1.replaceAll("\\", "/");
            let result = replace
            // console.log('result', result)
            let output = baseurl + result
            return output
        }
        else {
            return null
        }
    }

    onGotoNxtImg = () => {
        try {
            let index = this.state.temp_index + 1
            let allData = this.state.timeWise_filterdata
            console.log(index, allData)
            let selectedData = allData[index]
            console.log('selectedData198', selectedData)
            let image_src = this.getImage(selectedData.captured_image)
            this.setState({ modal_data: selectedData, image_src, temp_index: index })
        } catch (error) {

        }
    }

    onGotoPrevImg = () => {
        try {
            let index = this.state.temp_index - 1
            let allData = this.state.timeWise_filterdata
            console.log(index, allData)
            let selectedData = allData[index]
            let image_src = this.getImage(selectedData.captured_image)
            this.setState({ modal_data: selectedData, image_src, temp_index: index })
        } catch (error) {

        }
    }


    render() {
        if (this.state.dataloaded) {
            return (
                <React.Fragment>
                    <div className="page-content">
                        <MetaTags>
                            <title>Visual Inspection</title>
                        </MetaTags>
                        <Container fluid={true} style={{ minHeight: '100vh', background: 'white' }}>
                            {/* <Breadcrumbs title="Forms" breadcrumbItem="Form Layouts" /> */}
                            <Row>
                                <Col>
                                    <Link to="/inspectResult"><Button onClick={() => this.backButton()}>Back</Button></Link>
                                </Col>
                            </Row>
                            <Row >
                                <Col lg={12}>
                                    {/* <CardTitle className="text-center">View Info</CardTitle> */}
                                    <CardTitle className="text-center mb-4" style={{fontSize:"26px"}}>Inspection Result</CardTitle>
                                </Col>
                            </Row>
                            <Row>
                                <Col sm={4}>
                                    <Card className="bg-light" style={{borderRadius:"50px"}}>
                                        <CardBody className="d-flex align-items-center justify-content-center">
                                            <CardText className="card1" style={{ whiteSpace: "nowrap" }}>Component Name: {this.state.comp_name}</CardText>
                                        </CardBody>
                                    </Card>
                                </Col>
                                <Col sm={4}>
                                    <Card className="bg-light" style={{borderRadius:"50px"}}>
                                        <CardBody className="d-flex align-items-center justify-content-center"> 
                                            <CardText  className="card1" style={{ whiteSpace: "nowrap" }} >Component Code: {this.state.comp_code}</CardText>
                                        </CardBody>
                                    </Card>
                                </Col>
                                <Col sm={4}>
                                    <Card className="bg-light" style={{borderRadius:"50px"}}>
                                        <CardBody className="d-flex align-items-center justify-content-center">
                                            <CardText className="card1" style={{ whiteSpace: "nowrap" }}>Date: {this.state.date}</CardText>
                                        </CardBody>
                                    </Card>
                                </Col>
                                {/* <label>Component Name: {this.state.comp_name}</label> */}
                                {/* <Row><label>Component Code: {this.state.comp_code}</label></Row>
                                    <Row><label>Date: {this.state.date}</label></Row>    */}
                            </Row>

                            <Row className="mt-3 mb-3 custom-button-row">
                                <Col  className="text-center">
                                    <Button color="primary" className="w-sm m-1" onClick={() => { this.status_filter("") }}>
                                        <div>Total</div>
                                        <div>{this.state.okCount + this.state.notokCount + this.state.posblMatchCount + this.state.no_objCount + this.state.incorrect_obj}</div>
                                    </Button>
                                </Col>
                                <Col  className="text-center">
                                    <Button color="primary" className="w-sm m-1" onClick={() => { this.status_filter(this.state.positive) }}>
                                        <div>{this.state.config_positive}</div>
                                        <div>{this.state.okCount}</div>
                                    </Button>
                                </Col>
                                <Col  className="text-center">
                                    <Button color="primary" className="w-sm m-1" onClick={() => { this.status_filter(this.state.negative) }}>
                                        <div>{this.state.config_negative}</div>
                                        <div>{this.state.notokCount}</div>
                                    </Button>
                                </Col>
                                <Col  className="text-center">
                                    <Button color="primary" className="w-sm m-1" onClick={() => { this.status_filter("No Object Found") }}>
                                        <div>No object found</div>
                                        <div>{this.state.no_objCount}</div>
                                    </Button>
                                </Col>
                                <Col  className="text-center">
                                    <Button color="primary" className="w-sm m-1" onClick={() => { this.status_filter("Incorrect Object") }}>
                                        <div>Incorrect Object</div>
                                        <div>{this.state.incorrect_obj}</div>
                                    </Button>
                                </Col>
                            </Row>


                            {/* <Row className="p-2">
                                <Col lg={12}>
                                    <CardTitle className="text-center">View Info</CardTitle>
                                </Col>
                                <Col>
                                    <label>Component Name: {this.state.comp_name}</label>
                                    <Row><label>Component Code: {this.state.comp_code}</label></Row>
                                    <Row><label>Date: {this.state.date}</label></Row>
                                </Col>
                                <Row>
                                    <Col>
                                        <Button color="primary" className="w-md m-1" onClick={() => { this.status_filter("") }}> Total {"("} {this.state.okCount + this.state.notokCount + this.state.posblMatchCount + this.state.no_objCount} {")"}</Button>
                                    </Col>
                                    <Col>
                                        <Button color="primary" className="w-md m-1" onClick={() => { this.status_filter(this.state.positive) }}> {this.state.config_positive} {"("} {this.state.okCount} {")"}</Button>
                                    </Col>
                                    <Col>
                                        <Button color="primary" className="w-md m-1" onClick={() => { this.status_filter(this.state.negative) }}> {this.state.config_negative} {"("} {this.state.notokCount} {")"}</Button>
                                    </Col>
                                    <Col>
                                        <Button color="primary" className="w-md m-1" onClick={() => { this.status_filter(this.state.posble_match) }}> {this.state.config_posble_match} {"("} {this.state.posblMatchCount} {")"}</Button>
                                    </Col>
                                    <Col>
                                        <Button color="primary" className="w-md m-1" onClick={() => { this.status_filter("No Object Found") }}> No object found {"("} {this.state.no_objCount} {")"}</Button>
                                    </Col>
                                </Row>

                            </Row> */}
                            {
                                console.log('first...', this.state.timeWise_filterdata)
                            }

                            <div className="table-responsive">

                                <Table striped>
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Result</th>
                                            <th>Captured Image</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            this.state.timeWise_filterdata.map((data, index) => (

                                                <tr key={index}>
                                                    <td>{data.inspected_ontime}</td>
                                                    <td>{data.result}</td>
                                                    <td>
                                                        <img
                                                            onClick={() => this.setState({ showModal: true, modal_data: data, temp_index: index, image_src: this.getImage(data.captured_image) })}
                                                            style={{ width: 'auto', height: 100 }}
                                                            src={this.getImage(data.captured_image)}
                                                        />
                                                        {/* <Row>
                                                            <ImgOverlay
                                                                imgSrc={this.getImage(data.captured_image)}
                                                                bgColor='pink'
                                                                position='right'
                                                                width={100}                                                               
                                                            >
                                                                Component Name: {this.state.comp_name}
                                                            </ImgOverlay>
                                                        </Row> */}
                                                    </td>
                                                </tr>
                                            ))
                                        }
                                    </tbody>
                                </Table>
                            </div>
                            <Modal size="l" isOpen={this.state.showModal} centered={true}>
                                <div className="modal-header">
                                    <h5>Image</h5>
                                    <Button
                                        onClick={() =>
                                            this.setState({ showModal: false })
                                        }
                                        type="button"
                                        className="close mt-1"
                                        data-dismiss="modal"
                                        aria-label="Close"
                                    >
                                        <span aria-hidden="true">&times;</span>
                                    </Button>
                                </div>
                                <div className="modal-body">
                                    <div className="text-center">
                                        <img className="img-fluid" src={this.state.image_src} />
                                    </div>
                                    <Row>
                                        <br />
                                        <div>
                                            <Row className="mt-4">
                                                <Col sm={6} className="text-start">
                                                    Component Name: <b>{this.state.comp_name}</b>
                                                </Col>
                                                <Col sm={6} className="text-end">
                                                    Result:
                                                    <span style={{ color: (this.state.modal_data.result === ("No Objects Detected") || this.state.modal_data.result === "notok") ? "red" : "green" && (this.state.modal_data.result === "Possible Match") ? "orange" : "green" }}>
                                                        {this.state.modal_data.result}
                                                    </span>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col sm={6} className="text-start">Component Code: <b>{this.state.comp_code}</b> </Col>
                                                <Col sm={6} className="text-end">Date: <b>{this.state.modal_data.date}  {" "} </b> {""}Time: <b>{this.state.modal_data.inspected_ontime}</b>
                                                </Col>
                                            </Row>
                                        </div>
                                    </Row>
                                    <Row className="mt-4">
                                        <Col md={6} className="text-start">
                                            {
                                                this.state.temp_index !== 0 && <Button onClick={() => this.onGotoPrevImg()} >Previous</Button>
                                            }
                                        </Col>
                                        <Col md={6} className="text-end">
                                            {
                                                this.state.timeWise_filterdata.length !== this.state.temp_index + 1 &&
                                                <Button onClick={() => this.onGotoNxtImg()} >Next
                                                </Button>
                                            }
                                        </Col>
                                    </Row>
                                </div>
                                <Row>
                                    <Col md={12} className="text-center">
                                        ( {this.state.temp_index + 1} / {this.state.timeWise_filterdata.length})
                                    </Col>
                                </Row>
                                <div className="modal-footer">
                                    <button
                                        type="button"
                                        onClick={() =>
                                            this.setState({ showModal: false, })
                                        }
                                        className="btn btn-secondary"
                                        data-dismiss="modal"
                                    >
                                        Close
                                    </button>
                                </div>
                            </Modal>

                            {
                                this.state.timeWise_filterdata.length === 0 ?

                                    <div className="text-center mt-2">
                                        <h3>
                                            No Records found
                                        </h3>

                                    </div> : null
                            }
                        </Container>
                        {/* container-fluid */}
                    </div>
                </React.Fragment>
            );
        }
        else {
            return null
        }
    }
}
Report.propTypes = {
    history: PropTypes.any.isRequired,
};
export default Report;